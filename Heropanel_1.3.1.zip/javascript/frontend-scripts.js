jQuery(document).ready(function($) {
    // Your custom frontend scripts here
});
