jQuery(document).ready(function($) {
    $('.wp-comics-color-picker').wpColorPicker();
});
